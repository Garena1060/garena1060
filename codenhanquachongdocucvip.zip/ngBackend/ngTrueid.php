<?php 
  echo "bạn , chúc bạn may mắn"; // Key Để Chạy 

/* Châu Thế Bảo */
?>