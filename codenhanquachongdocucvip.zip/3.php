
                <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/1.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/2.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/3.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/4.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/5.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/6.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			        <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/7.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			        <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/8.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			        <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/sung/9.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			    
			