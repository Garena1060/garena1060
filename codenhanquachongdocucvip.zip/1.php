
                <div class="box">
			       <div class="prize">
			           <img src="https://i.imgur.com/eN52lP8.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/2.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/3.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/4.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/5.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/6.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/7.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/ChauTheBao/do/8.png">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="https://i.imgur.com/aRij1gN.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Nhận</span>
			       </div>
			    </div>
			    
			 
			    
			    